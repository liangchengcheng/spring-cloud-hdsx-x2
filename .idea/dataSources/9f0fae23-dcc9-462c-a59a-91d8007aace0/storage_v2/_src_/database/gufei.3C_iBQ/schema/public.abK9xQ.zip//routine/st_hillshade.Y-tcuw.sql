create function st_hillshade(rast raster, nband integer DEFAULT 1, pixeltype text DEFAULT '32BF'::text, azimuth double precision DEFAULT 315.0, altitude double precision DEFAULT 45.0, max_bright double precision DEFAULT 255.0, scale double precision DEFAULT 1.0, interpolate_nodata boolean DEFAULT false) returns raster
    immutable
    language sql
as
$$
SELECT public.ST_hillshade($1, $2, NULL::raster, $3, $4, $5, $6, $7, $8)
$$;

alter function st_hillshade(raster, integer, text, double precision, double precision, double precision, double precision, boolean) owner to postgres;

