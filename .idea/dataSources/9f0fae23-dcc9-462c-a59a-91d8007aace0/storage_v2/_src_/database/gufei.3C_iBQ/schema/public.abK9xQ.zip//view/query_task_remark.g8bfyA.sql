create view query_task_remark(wtid, remark) as
    SELECT tb_wtdc_check2.wtid,
           tb_wtdc_check2.remark
    FROM tb_wtdc_check2
    UNION ALL
    SELECT tb_wtdc_check1.wtid,
           tb_wtdc_check1.remark
    FROM tb_wtdc_check1
    UNION ALL
    SELECT tb_gf_yswt_wxzx.id AS wtid,
           tb_gf_yswt_wxzx.remark
    FROM tb_gf_yswt_wxzx;

alter table query_task_remark
    owner to watersys;

