create view view_wxzx(sewagenumber, xzqh, typecode, pc, typename, province, city, county, ptx, pty, areas, zbhj,
                      remark) as
SELECT a.sewagenumber,
       a.xzqh,
       a.type  AS typecode,
       a.pc,
       CASE
           WHEN ((a.type)::text = '0'::text) THEN '卫星中心'::text
           WHEN ((a.type)::text = '1'::text) THEN '无人机航拍'::text
           WHEN ((a.type)::text = '2'::text) THEN '2018年排查'::text
           ELSE NULL::text
           END AS typename,
       c.name  AS province,
       d.name  AS city,
       f.name  AS county,
       a.ptx,
       a.pty,
       b.areas,
       b.zbhj,
       a.remark
FROM ((((tb_gf_yswt_wxzx a
    LEFT JOIN tb_gufei_wgs84 b ON (((a.geomid)::text = (b.id)::text)))
    LEFT JOIN tb_xzqh c ON (((c.code)::text = ("substring"((a.xzqh)::text, 1, 2) || '0000'::text))))
    LEFT JOIN tb_xzqh d ON (((d.code)::text = ("substring"((a.xzqh)::text, 1, 4) || '00'::text))))
         LEFT JOIN tb_xzqh f ON (((f.code)::text = (a.xzqh)::text)))
ORDER BY a.xzqh;

alter table view_wxzx
    owner to watersys;

