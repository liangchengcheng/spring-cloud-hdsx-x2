create function st_valuepercent(rastertable text, rastercolumn text, nband integer, searchvalue double precision, roundto double precision DEFAULT 0) returns double precision
    stable
    strict
    language sql
as
$$
SELECT ( public._ST_valuecount($1, $2, $3, TRUE, ARRAY[$4]::double precision[], $5)).percent
$$;

alter function st_valuepercent(text, text, integer, double precision, double precision) owner to postgres;

