create view query_task_common(id, xzqh, number, address, wtlb) as
    SELECT tb_wtdc_wtqd.id,
           tb_wtdc_wtqd.xzqh,
           tb_wtdc_wtqd.gfdfwbh AS number,
           tb_wtdc_wtqd.address,
           tb_wtdc_wtqd.wtlb
    FROM tb_wtdc_wtqd
    UNION ALL
    SELECT tb_gf_yswt_wxzx.id,
           tb_gf_yswt_wxzx.xzqh,
           (tb_gf_yswt_wxzx.sewagenumber)::character varying AS number,
           tb_gf_yswt_wxzx.address,
           CASE
               WHEN (tb_gf_yswt_wxzx.id IS NOT NULL) THEN 2
               ELSE NULL::integer
               END                                           AS wtlb
    FROM tb_gf_yswt_wxzx;

alter table query_task_common
    owner to watersys;

