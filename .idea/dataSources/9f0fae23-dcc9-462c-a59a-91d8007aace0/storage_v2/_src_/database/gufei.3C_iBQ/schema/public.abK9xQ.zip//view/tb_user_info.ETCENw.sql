create view tb_user_info(id, "phoneNum", password, "realName", "jobUnitCode", code, "isAdministrator", "isAvailabled",
                         "createTime", "userName", "jobUnit", roleid, expirationtime, remark) as
SELECT t.id,
       t."phoneNum",
       t.password,
       t."realName",
       t."jobUnitCode",
       t.code,
       t."isAdministrator",
       t."isAvailabled",
       t."createTime",
       t."userName",
       t."jobUnit",
       t.roleid,
       t.expirationtime,
       t.remark
FROM dblink('dbname=dbuser host=192.168.0.181 port=5432 user=watersys password=watersys'::text,
            'select * from tb_user_info'::text) t(id character varying, "phoneNum" character varying,
                                                  password character varying, "realName" character varying,
                                                  "jobUnitCode" character varying, code character varying,
                                                  "isAdministrator" integer, "isAvailabled" integer,
                                                  "createTime" timestamp without time zone,
                                                  "userName" character varying, "jobUnit" character varying,
                                                  roleid character varying, expirationtime character varying,
                                                  remark character varying);

alter table tb_user_info
    owner to watersys;

