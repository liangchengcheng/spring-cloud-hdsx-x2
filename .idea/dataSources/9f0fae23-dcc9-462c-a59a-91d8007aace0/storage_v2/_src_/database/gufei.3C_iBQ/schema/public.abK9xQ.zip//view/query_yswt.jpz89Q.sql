create view query_yswt(id, pc, sewagenumber, ptx, pty) as
    SELECT tb_gf_yswt_wxzx.id,
           tb_gf_yswt_wxzx.pc,
           tb_gf_yswt_wxzx.sewagenumber,
           tb_gf_yswt_wxzx.ptx,
           tb_gf_yswt_wxzx.pty
    FROM tb_gf_yswt_wxzx
    UNION ALL
    SELECT tb_gf_yswt_xfjb.id,
           tb_gf_yswt_xfjb.pc,
           tb_gf_yswt_xfjb.sewagenumber,
           tb_gf_yswt_xfjb.ptx,
           tb_gf_yswt_xfjb.pty
    FROM tb_gf_yswt_xfjb;

alter table query_yswt
    owner to watersys;

