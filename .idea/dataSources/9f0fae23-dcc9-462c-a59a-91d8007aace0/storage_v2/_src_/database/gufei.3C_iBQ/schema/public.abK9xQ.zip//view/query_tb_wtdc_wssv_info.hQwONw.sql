create view query_tb_wtdc_wssv_info(id, surveycode, title) as
SELECT tb_wtdc_wssv_info.id,
       tb_wtdc_wssv_info.surveycode,
       tb_wtdc_wssv_info.title
FROM tb_wtdc_wssv_info;

alter table query_tb_wtdc_wssv_info
    owner to watersys;

