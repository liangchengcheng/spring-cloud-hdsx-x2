create function st_buffer(geometry, double precision, text) returns geometry
    immutable
    strict
    language sql
as
$$
SELECT public._ST_Buffer($1, $2,
		CAST( regexp_replace($3, '^[0123456789]+$',
			'quad_segs='||$3) AS cstring)
		)

$$;

comment on function st_buffer(geometry, double precision, text) is 'args: g1, radius_of_buffer, buffer_style_parameters - (T)Returns a geometry covering all points within a given distancefrom the input geometry.';

alter function st_buffer(geometry, double precision, text) owner to postgres;

