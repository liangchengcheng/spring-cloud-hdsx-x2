create view query_tb_gf_gpdb_zgjd(xchsid, gpdbzglxname, gpdbzglx, zrztxzqhname, zgjdid, zzjdtb, sewageid, checkstate,
                                  createtime, checkremark, checktime, createrid, xxdzcode, isgf, xzqh, zrztxzqh, jyqtdw,
                                  zrr, wtly, gflx, wtlyname, dwbh, zgjzmqjd, zgqkstatusstr, zgqkstatus, gfjbqkstatusstr,
                                  gfjbqkstatus, cdhjstatusstr, cdhjstatus) as
SELECT a.id                             AS xchsid,
       um.name                          AS gpdbzglxname,
       a.zglx                           AS gpdbzglx,
       qh.name                          AS zrztxzqhname,
       b.id                             AS zgjdid,
       CASE
           WHEN (b.xchsbid IS NOT NULL) THEN 1
           ELSE 0
           END                          AS zzjdtb,
       a.yswtid                         AS sewageid,
       a.checkstate,
       a.createtime,
       a.checkremark,
       a.checktime,
       a.createrid,
       a.xxdzcode,
       a.isgf,
       substr((a.xxdzcode)::text, 1, 6) AS xzqh,
       l.xzqh                           AS zrztxzqh,
       l.jyqtdw,
       l.zrr,
       a.wtly,
       en.name                          AS gflx,
       h.name                           AS wtlyname,
       a.dwbh,
       CASE
           WHEN (b.zgjzmqjd IS NOT NULL) THEN b.zgjzmqjd
           ELSE (0)::bigint
           END                          AS zgjzmqjd,
       CASE
           WHEN (i.id IS NOT NULL) THEN '已填写'::text
           ELSE '未填写'::text
           END                          AS zgqkstatusstr,
       CASE
           WHEN (i.id IS NOT NULL) THEN 1
           ELSE 0
           END                          AS zgqkstatus,
       CASE
           WHEN (j.id IS NOT NULL) THEN '已填写'::text
           ELSE '未填写'::text
           END                          AS gfjbqkstatusstr,
       CASE
           WHEN (j.id IS NOT NULL) THEN 1
           ELSE 0
           END                          AS gfjbqkstatus,
       CASE
           WHEN (k.id IS NOT NULL) THEN '已填写'::text
           ELSE '未填写'::text
           END                          AS cdhjstatusstr,
       CASE
           WHEN (k.id IS NOT NULL) THEN 1
           ELSE 0
           END                          AS cdhjstatus
FROM ((((((((((((((tb_gf_check_gfxc a
    LEFT JOIN (SELECT a_1.id,
                      a_1.xchsbid,
                      a_1.zgqxkssj,
                      a_1.zgqxjssj,
                      a_1.zgjzsfwc,
                      a_1.zgjzmqjd,
                      a_1.zgjzscjd,
                      a_1.remark,
                      a_1.createtime,
                      a_1.createrid,
                      a_1.checkstate,
                      a_1.checktime,
                      a_1.checkerid,
                      a_1.checkremark
               FROM tb_gf_zgjd_gpdb a_1
               WHERE (a_1.createtime = (SELECT max(b_1.createtime) AS max
                                        FROM tb_gf_zgjd_gpdb b_1
                                        WHERE ((a_1.xchsbid)::text = (b_1.xchsbid)::text)))) b ON (((a.id)::text = (b.xchsbid)::text)))
    LEFT JOIN (SELECT a_1.id,
                      a_1."phoneNum",
                      a_1.password,
                      a_1."realName",
                      a_1."jobUnitCode",
                      a_1.code,
                      a_1."isAdministrator",
                      a_1."isAvailabled",
                      a_1."createTime",
                      a_1."userName",
                      a_1."jobUnit",
                      a_1.roleid,
                      a_1.expirationtime,
                      a_1.remark,
                      c_1.name AS jobunit
               FROM (tb_user_info a_1
                        LEFT JOIN tb_unit c_1 ON (((a_1."jobUnitCode")::text = (c_1.code)::text)))) c ON (((b.id)::text = (a.createrid)::text)))
    LEFT JOIN (SELECT a_1.id,
                      a_1."phoneNum",
                      a_1.password,
                      a_1."realName",
                      a_1."jobUnitCode",
                      a_1.code,
                      a_1."isAdministrator",
                      a_1."isAvailabled",
                      a_1."createTime",
                      a_1."userName",
                      a_1."jobUnit",
                      a_1.roleid,
                      a_1.expirationtime,
                      a_1.remark,
                      d_1.name AS jobunit
               FROM (tb_user_info a_1
                        LEFT JOIN tb_unit d_1 ON (((a_1."jobUnitCode")::text = (d_1.code)::text)))) d ON (((c.id)::text = (a.checkerid)::text)))
    LEFT JOIN tb_xzqh e ON (((e.code)::text = (substr((a.xxdzcode)::text, 1, 2) || '0000'::text))))
    LEFT JOIN tb_xzqh f ON (((f.code)::text = (substr((a.xxdzcode)::text, 1, 4) || '00'::text))))
    LEFT JOIN tb_xzqh g ON (((g.code)::text = substr((a.xxdzcode)::text, 1, 6))))
    LEFT JOIN tb_gf_enum h ON (((h.code)::text = (a.wtly)::text)))
    LEFT JOIN tb_gf_enum en ON (((en.code)::text = (a.gfcpzl)::text)))
    LEFT JOIN tb_gf_zrzt l ON (((a.id)::text = (l.mapperid)::text)))
    LEFT JOIN tb_xzqh qh ON (((l.xzqh)::text = (qh.code)::text)))
    LEFT JOIN tb_gf_zgqk i ON (((i.xchsbid)::text = (a.id)::text)))
    LEFT JOIN tb_gf_base_info j ON (((j.xchsbid)::text = (a.id)::text)))
    LEFT JOIN tb_gf_cdhjdc k ON (((k.xchsbid)::text = (a.id)::text)))
         LEFT JOIN tb_gf_enum um ON (((um.code)::text = (a.zglx)::text)))
WHERE (((a.zglx)::text <> '5502'::text) AND (a.isgf = 1))
ORDER BY a.dwbh;

alter table query_tb_gf_gpdb_zgjd
    owner to watersys;

