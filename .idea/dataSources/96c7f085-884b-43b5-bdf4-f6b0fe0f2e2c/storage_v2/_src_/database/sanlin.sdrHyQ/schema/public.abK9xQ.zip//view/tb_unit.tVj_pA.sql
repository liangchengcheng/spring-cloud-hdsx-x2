create view tb_unit(id, name, code, createtime, parentcode, isupdate, xzqh, type, remark, telephone, address, email,
                    state) as
SELECT tb_unit.id,
       tb_unit.name,
       tb_unit.code,
       tb_unit.createtime,
       tb_unit.parentcode,
       tb_unit.isupdate,
       tb_unit.xzqh,
       tb_unit.type,
       tb_unit.remark,
       tb_unit.telephone,
       tb_unit.address,
       tb_unit.email,
       tb_unit.state
FROM dblink('dbname=dbuser host=192.168.0.181 port=5432 user=watersys password=watersys'::text,
            'select * from tb_unit'::text) tb_unit(id character varying, name character varying, code character varying,
                                                   createtime timestamp without time zone, parentcode character varying,
                                                   isupdate integer, xzqh character varying, type integer,
                                                   remark character varying, telephone character varying,
                                                   address character varying, email character varying, state smallint);

alter table tb_unit
    owner to watersys;

